HARDY THEME 2.0 By Mariux

INSTALLATION:

First of all, UNTAR THE ARCHIVE.

Then, follow these instructions to install the components.

	*GTk theme
Install this packages:
§ sudo aptitude install gtk2-engines-murrine
then copy "Hardy-Mariux 2.0" in your /home/.themes directory
Go in System -> Preferences -> Appearance->Customize then select "Hardy-Mariux 2.0" to choose this gtk theme.
If you want sudo apps to run with Hardy-Mariux 2.0 theme, just copy as sudo the Hardy-Mariux 2.0 directory in your usr/share/themes directory.

        *Icons + Firefox Theme
To install the icons there are 2 ways:
1)Install the Tangerine.tar.tgz with Appearance Manager (System -> Preferences -> Appearance).
or
2)In terminal, run 
§ sudo apt-get install tangerine-icon-theme. Then Select in Appearance.

For the Firefox theme, run in terminal 
§ sudo apt-get install firefox-themes-ubuntu
then open Firefox->Tools->Add-ons then select Tangerine theme, then restart Firefox.

	*Wallpaper
Make a right clic on your Desktop, and enter in the menu "change your wallpaper", then search for the directory where you untarred Hardy-Mariux.
The Wallpaper is already contained into the pc for every Ubuntu User. Others must install it.

        *Emerald
Just double click on the files to install them. Then select Hardy 2.0 - Standard or Hardy 2.0 - OSX

        *GDM Theme
Open System->Administration->Login Window
Go to "Local", clic Add, then select the tar.gz file, OK, then select Mariux Glossy Hardy.


	*Compiz Fusion Settings
Just open "Advanced Desktop Effects Settings"-> Preferences-> Profile-> Import 
then select "Mariux.profile" into the Hardy-Mariux/Compiz Fusion Settings directory

        *conky Theme
first install conky with
§ sudo apt-get install conky
then copy ".conkyrc" in your /home directory.
to make conky start, click Alt+F2 then execute the command "conky".
If you want conky to start on startup, just open System->Preferencies->Session then add a new startup program with "conky" in command.

        *AWN theme
Just open AWN-Manager, click on themes, then install QV_Glass_3D.tgz

        *Panel Image
Left click on your panel, Properties->Background->Background image then select "hardy2-0-panelimage.png".

        *Skydome
Open Advanced Desktop Effects Settings->Cube Desktop-> Appearance->Skydome then select the Autumn_Morning.jpg file.


Thanks to:

Ubuntu Art Team for the icons / Wallpaper
Ubuntu Core Developers for Firefox themes
 


